import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите число: ");
        int number = scanner.nextInt();
        int number1 = number >>1;
        System.out.println(number1);





    }
}

//4 Пользователь вводит целое число.
// Напишите программу, которая делит это число на 2 и выводит результат.
// Остаток деления можно отбросить.
// Операторы деления /, умножения * и остатка от деления % применять нельзя.